// Sukurkite kintamąjį age ir priskirkite jam savo amžių. Parodykite ‘I’m %age% old!’

let birthdate = 1996;
let today = new Date();
let age = today.getUTCFullYear() - birthdate;

console.log(today.getUTCFullYear());
console.log('I`m ' + age + ' years old!');


// let birthday = new Date(1996, 8, 23);
// let date = new Date();
// let [month, day, year] = [date.getMonth(), date.getDate(), date.getFullYear()];
//
// let age_today = [month, day, year] - birthday;
//
// console.log([month, day, year]);
// console.log(age_today);